class Person{
    String name;
    String surname;
    String address;
    String phone;
    int ID;
}