class RetailCustomer extends Customer {
}