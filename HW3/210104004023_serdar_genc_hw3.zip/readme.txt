***MAKEFILE COMMANDS***
make: create class files
make run: run program
make doc: create javadoc folder
make clean: delete report.txt file and class files
make cleandoc: delete javadoc folder

***ACCEPTED CATEGORIES***
tv
smart phone
smart watch
laptop
headphone
